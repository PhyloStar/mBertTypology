import glob, sys
from collections import defaultdict
import itertools as it
import numpy as np
from scipy.spatial.distance import cosine

lang_script_map = defaultdict()

for line in open("panlex_swadesh/langs207.txt", "r"):
    arr = line.strip().split("\t")
#    if arr[0] != arr[-1]: print(line)

    script = arr[3].replace(" ","_").replace(",","")
    lang_script_map[arr[0]] = arr[-1]+"_"+script


lang_iso = defaultdict(list)

for line in open("mbert_ISO_langs.txt", "r"):
    lang, _, iso = line.strip("\n").split("\t")
    lang_iso[iso].append(lang)

fnames = []
iso_fnames = defaultdict(list)

for fname in glob.glob("panlex_swadesh/swadesh207/*"):
    iso = fname.split("/")[-1].split("-")[0]
    panlex_id = fname.split("/")[-1]
    panlex_id = panlex_id.replace(".txt", "")

    if iso in lang_iso:
        fnames.append(fname)
        iso_fnames[iso].append(fname)
        print(iso, fname, lang_script_map[panlex_id], sep="\t")

print("Nr. languages ", len(iso_fnames))

for k, v in iso_fnames.items():
    if len(v) > 1: print(k, v)

import torch 
from transformers import *

tokenizer = BertTokenizer.from_pretrained('bert-base-multilingual-cased')                                                                                                    
model = BertModel.from_pretrained('bert-base-multilingual-cased', output_hidden_states=True)                                                                                                            

#with torch.no_grad():
#    for layer_nr in range(1, 13):
#        for fname in fnames:
#            print(fname)
#            iso3 = fname.split("/")[-1].replace(".txt", "")
#            with open("bert_layers_vectors/mbert_cos_layer_"+iso3+"_layer-"+str(layer_nr)+".txt", "w") as fw:

#                words1= [line.strip("\n").split("\t")[0] for line in open(fname, "r")]
#                print(len(words1))
#                for w1 in words1:
#                    if w1 == "":
#                        print("NULL", file=fw)
#                    else:    
#                        w1_tensor = torch.tensor([tokenizer.encode(w1, add_special_tokens=True)])           
#                        w1_vec = model(w1_tensor)[2][layer_nr][0,1:-1].mean(dim=0).detach().numpy()      
#                        w1_str = ",".join(map(str, list(w1_vec)))
#                        print(w1_str, file=fw, flush=True)

import os

dir1 = "swadesh_bert_layers_vectors/"
dir2 = "swadesh_xlmr_layers_vectors/"

if not os.path.isdir(dir1):
    os.mkdir(dir1)

if not os.path.isdir(dir2):
    os.mkdir(dir2)

with torch.no_grad():
    for fname in fnames:
        print(fname)
        iso3 = fname.split("/")[-1].replace(".txt", "")
        words= [line.strip("\n").split("\t")[-1] for line in open(fname, "r")]
        print(len(words))
        for w1 in words:
            w1_vec, w1_str = [], ""
            if w1 == "":
                w1_str = "NULL"
            else:    
                w1_tensor = torch.tensor([tokenizer.encode(w1, add_special_tokens=True)])
                w1_vec = model(w1_tensor)[2]#[layer_nr][0,1:-1].mean(dim=0).detach().numpy()      
                w1_str = ",".join(map(str, list(w1_vec)))

            for layer_nr in range(0, 13):
                with open("swadesh_bert_layers_vectors/mbert_cos_layer_"+iso3+"_layer-"+str(layer_nr)+".txt", "a") as fw:
                    if w1_str != "NULL":
                        temp_vec = w1_vec[layer_nr][0,1:-1].mean(dim=0).detach().numpy()
                        #print(layer_nr, temp_vec.shape)
                        w1_str = ",".join(map(str, list(temp_vec)))
                    print(w1_str, file=fw, flush=True)                    

import torch
xlmr = torch.hub.load('pytorch/fairseq', 'xlmr.large')
xlmr.eval()

with torch.no_grad():
    for fname in fnames:
        print(fname)
        iso3 = fname.split("/")[-1].replace(".txt", "")
        words= [line.strip("\n").split("\t")[-1] for line in open(fname, "r")]
        print(len(words))
        for w1 in words:
            w1_vec, w1_str = [], ""
            if w1 == "":
                w1_str = "NULL"
#                print("NULL", file=fw)
            else:
                w1_tensor = xlmr.encode(w1)   
                w1_vec = xlmr.extract_features(w1_tensor,return_all_hiddens=True)
                print(fname, w1)
                
                w1_str = ",".join(map(str, list(w1_vec)))

            for layer_nr in range(0, 25):
                with open("swadesh_xlmr_layers_vectors/xlmr_cos_layer_"+iso3+"_layer-"+str(layer_nr)+".txt", "a") as fw:
                    if w1_str != "NULL":
                        temp_vec = np.array(w1_vec[layer_nr][0,1:-1].mean(dim=0).detach().numpy())
                        w1_str = ",".join(map(str, list(temp_vec)))
                    print(w1_str, file=fw, flush=True)

