The correlations we report in the paper are extracted from the full table in ranking-correlations.tsv, which were computed on the basis of the scores in mapped-and-ranked-lists.tsv.

mapped-and-ranked-lists.tsv aligns all the concept lists we used, and maps them to Concepticon (including proposed names for concepts previously not included) and to WOLD. The mapping may differ from the one specified by Concepticon in a few details, and also from NorthEuraLex' original definitions: e.g. NEL's Stein::N is mapped to ROCK, but for purposes of comparison to other lists we map it to STONE.

mapped-and-ranked-lists.tsv further contains the lgc (with standard deviation) and inf measures, the combined measure, and the resulting ranks, as well as as the relevant data for the replica study, extracted from WOLD (http://wold.clld.org), which provides borrowed, age and simplicity scores for all its concepts. We re-calculated Tadmor et al.'s (2009) ranking by multiplying the three scores. We left out the representation factor, for the following reasons: 1. The "representation" reported is not identical to Tadmor's usage of the term: He meant the percentage of languages with at least one entry, WOLD reports the number of entries (over the 41 languages, with possible multiple entries). Tadmor's meaning cannot be easily retrieved from the data available. 2. Representation is near 100% for all important concepts. 



