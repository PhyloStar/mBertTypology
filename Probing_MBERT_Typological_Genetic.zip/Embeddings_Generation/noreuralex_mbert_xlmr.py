import glob, sys
from collections import defaultdict
import itertools as it
import numpy as np
from scipy.spatial.distance import cosine

noreuralex = defaultdict()

mbert_nulex_langs = [x.strip() for x in open("mbert_noreuralex_langs.txt", "r")]

with open("NorthEuralex/northeuralex-0.9-forms.tsv", "r") as fr:
    header = fr.readline()
    for line in fr:
        arr = line.strip().split("\t")
        iso, concept, word = arr[0], arr[2], arr[3]
        if iso in mbert_nulex_langs:
            noreuralex[iso,concept] = word

isos, concepts = [], []

isos, concepts = zip(*list(noreuralex.keys()))

isos, concepts = set(isos), set(concepts)

print(*isos, sep="\n")

print(*concepts, sep="\n")


import os

dir1 = "noreuralex_bert_layers_vectors/"
dir2 = "noreuralex_xlmr_layers_vectors/"

if not os.path.isdir(dir1):
    os.mkdir(dir1)

if not os.path.isdir(dir2):
    os.mkdir(dir2)

import torch 
from transformers import *

tokenizer = BertTokenizer.from_pretrained('bert-base-multilingual-cased')                                                                                                    
model = BertModel.from_pretrained('bert-base-multilingual-cased', output_hidden_states=True)                                                                                                            

with torch.no_grad():
    for iso3 in isos:
        print(iso3)
        for concept in concepts:
            w1_vec, w1_str = [], ""
            if (iso3, concept) not in noreuralex:
                w1_str = "NULL"
            else:
                w1 = noreuralex[iso3,concept]
                w1_tensor = torch.tensor([tokenizer.encode(w1, add_special_tokens=True)])
                w1_vec = model(w1_tensor)[2]#[layer_nr][0,1:-1].mean(dim=0).detach().numpy()      
                w1_str = " NOT NULL "

            for layer_nr in range(0, 13):
                with open("noreuralex_bert_layers_vectors/mbert_cos_layer_"+iso3+"_layer-"+str(layer_nr)+".txt", "a") as fw:
                    if w1_str != "NULL":
                        temp_vec = w1_vec[layer_nr][0,1:-1].mean(dim=0).detach().numpy()
                        w1_str = concept
                        w1_str = ",".join(map(str, list(temp_vec)))
                    print(w1_str, file=fw, flush=True)                    


import torch
xlmr = torch.hub.load('pytorch/fairseq', 'xlmr.large')
xlmr.eval()

with torch.no_grad():
    for iso3 in isos:
        print(iso3)
        for concept in concepts:
            w1_vec, w1_str = [], ""
            if (iso3, concept) not in noreuralex:
                w1_str = "NULL"
            else:
                w1 = noreuralex[iso3,concept]
                w1_tensor = xlmr.encode(w1)
                w1_vec = xlmr.extract_features(w1_tensor,return_all_hiddens=True)
                w1_str = " NOT NULL "

            for layer_nr in range(0, 25):
                with open("noreuralex_xlmr_layers_vectors/xlmr_cos_layer_"+iso3+"_layer-"+str(layer_nr)+".txt", "a") as fw:
                    if w1_str != "NULL":
                        temp_vec = np.array(w1_vec[layer_nr][0,1:-1].mean(dim=0).detach().numpy())
                        w1_str = ",".join(map(str, list(temp_vec)))
                    print(w1_str, file=fw, flush=True)

