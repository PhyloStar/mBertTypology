#!/bin/bash

#for i in {0..12..1}
#  do 
#     echo "$i"
#     python3 worker_mbert_distances.py $i &
#done


#for i in {0..24..1}
#  do 
#     echo "$i"
#     python3 worker_xlmr_distances.py $i &
#done

for i in {0..12..1}
  do 
     echo "$i"
     python3 worker_swadesh_mbert_distances.py $i &
done


for i in {0..24..1}
  do 
     echo "$i"
     python3 worker_swadesh_xlmr_distances.py $i &
done
