import sys, glob
import itertools as it
from scipy.spatial.distance import cosine
import numpy as np
from sklearn.metrics.pairwise import cosine_similarity

from collections import defaultdict

layer_nr = sys.argv[1]

fnames = glob.glob("../swadesh_bert_layers_vectors/*_layer-"+layer_nr+".txt")
i = 0
corrs_file = "swadesh_mbert-"+str(layer_nr)+"-cossim-corrs.txt"
with open(corrs_file, "w") as fw:
    corrs_dict = defaultdict(list)
    
    for f1, f2 in it.combinations(fnames, r=2):
        distance, nr_syns = 0.0, 0.0

        lines1, lines2 = open(f1, "r").readlines(), open(f2, "r").readlines()

        for i, X in enumerate(zip(lines1, lines2)):
            line1, line2 = X[0], X[1]
            if "NULL" in line1 or "NULL" in line2: continue

            line1_vec = line1.strip("\n").split(",")
            line2_vec = line2.strip("\n").split(",")
        
            line1_vec = list(map(float, line1_vec))
            line2_vec = list(map(float, line2_vec))
            
#            corrs_dict[i].append(cosine_similarity(line1_vec, line2_vec))

            sim = np.dot(line1_vec, line2_vec)/(np.linalg.norm(line1_vec)*np.linalg.norm(line2_vec))
            corrs_dict[i].append(sim)
#            corrs_dict[i].append(np.dot(line1_vec, line2_vec))

    print("ID", "Mean", "Stdev", "Min", "Max", file=fw, sep="\t")
    for k in range(0,207):
        v = corrs_dict[k]
        print(k, np.mean(v), np.std(v), np.min(v),np.max(v), file=fw, sep="\t")
            
#            distance += cosine(line1_vec, line2_vec)
#            nr_syns += 1
#        distance = distance/nr_syns
#        i += 1
        #print(i, f1.split("/")[-1].replace(".txt", "").split("_")[3], f2.split("/")[-1].replace(".txt", "").split("_")[3], distance, sep="\t", flush=True)
#        print(f1.split("/")[-1].replace(".txt", "").split("_")[3], f2.split("/")[-1].replace(".txt", "").split("_")[3], distance, sep="\t", flush=True, file=fw)

