#!/bin/bash

for i in {0..12..1}
  do 
     echo "$i"
     python3 stable.py $i &
done

