import glob, csv

from collections import defaultdict

from scipy.stats import spearmanr as correl
from scipy.stats import pearsonr as pcorrel

import numpy as np

swadesh_concepticon = [x.replace("\n","") for x in open("swadesh207_concepticon_map.txt", "r")]

rankings = defaultdict(lambda: defaultdict())

header = ["Holman ranking value", "Pagel mean rate", "Petroni & Serva", "Peust ranking", "Rama & Borin score",  "Tadmor score", "Tadmor score (replica)", "WOLD age score", "WOLD borrowed score", "WOLD simplicity score", "inf"]

with open("../Embeddings_Generation/NorthEuralex/basicness_and_stability_supplement/mapped-and-ranked-lists.tsv", "r") as csvfile:
    reader = csv.DictReader(csvfile,delimiter="\t")
    for row in reader:
        meaning = row["concepticon"]
        if meaning in swadesh_concepticon:
            for rank_list_name in header:
                if len(row[rank_list_name]) > 0:
                    rankings[rank_list_name][meaning] = float(row[rank_list_name])
#                if len(row[rank_list_name]) < 1: print(rank_list_name)
        


scores = defaultdict(lambda: defaultdict(float))

for fname in sorted(glob.glob("swadesh_mbert*cossim-corrs.txt")):
    print(fname)
    layer_nr = fname.split("-")[1]
    columns = defaultdict(list)

    with open(fname, "r") as fr:
        reader = csv.DictReader(fr,delimiter="\t")
        for row in reader:
            for (k,v) in row.items():
                columns[k].append(v)


    print(columns.keys())

    for rank_list_name in rankings:
        
        for k in columns:
            if k =="ID": continue
            rank_vec, tgt_vec = [], []
            for i, m in enumerate(swadesh_concepticon):
                if m in rankings[rank_list_name]:
                    rank_vec.append(float(rankings[rank_list_name][m]))
                    tgt_vec.append(float(columns[k][i]))
                
            spearman = correl(rank_vec,tgt_vec)
#            print(rank_list_name, np.array(rank_vec), np.array(tgt_vec))
            rankcorr, pval = spearman
            if pval <0.01:
                print(layer_nr, rank_list_name, k, rankcorr, len(tgt_vec), sep="\t")
                scores[k][rank_list_name,layer_nr] = rankcorr


for k in sorted(list(scores.keys())):

    layer_nrs = list(range(0,13))
    print("", "",*layer_nrs, sep="\t")
    for rank_list_name in rankings:
        scores_vec = [scores[k][rank_list_name,str(layer_nr)] for layer_nr in layer_nrs]
        print(k, rank_list_name, *scores_vec, sep="\t")
    print()        
